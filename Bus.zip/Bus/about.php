<?php include_once'header2.php'; ?>
    
<section id="contact">
  <div class="container">
    <div class="well well-sm" style="text-align: center;background: #009cd9;">
      <h3><strong>Online Bus Ticket Reservation System</strong></h3>
    </div>
  
  <div class="row">
	<div class="well" style="margin: 0px 20px 0px 20px; background-color: #cbcbcb;">
		<h3>OBRS is a system that helps people to buy their ticket at home thought the help of any device capable of browsing.</h3>
		<h3>Terms & condition</h3>
		<p>1.You can capable of booking ticket when you are become a user of our system(first Up in and then logged in).</p>
		<p>2.You can contact with us through contact button displayed at homepage.</p>
		<p>3.You can not buy more than four ticket in a day.</p>
	</div>
		<br>
		
		<div style="text-align: center;">
			<h3><strong>Group Work Done By</strong></h3>
		</div>
		<div class="w3-row w3-container">
		  <div class="w3-col s4 w3-green w3-center">
			<div class="card">
			  <img src="images/shadequl.jpg" alt="John" style="width: 87%;padding-top: 19px;">
			  <h2>MD. Shadequl Islam</h2>
			  <p class="title">St. ID: 1420118</p>
			  <p>Institution: SASTC</p>
			
			</div>
		  </div>
		  <div class="w3-col s4 w3-dark-grey w3-center">
			<div class="card">
			  <img src="images/kasmery.jpg" alt="John" style="width: 87%;padding-top: 19px;">
			  <h2>Kashmery Aktar</h2>
			  <p class="title">St. ID: 1420109</p>
			  <p>Institution: SASTC</p>
			  
			</div>
		  </div>
		  <div class="w3-col s4 w3-green w3-center">
			<div class="card">
			  <img src="images/forhad.jpg" alt="John" style="width: 87%;padding-top: 19px;">
			  <h2>Sohel Rana</h2>
			  <p class="title">St. ID: 1420119</p>
			  <p>Institution: SASTC</p>
			 
			</div>
		  </div>
		</div>

  </div>
</section>
<?php 
include'footer.php';
 ?>
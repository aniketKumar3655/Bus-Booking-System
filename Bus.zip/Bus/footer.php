<footer id="footer_section" class="footer_section"><!-- start footer section -->
      <div class="container">
         <div class="footer_inner">
           <p>&copy; Bus Booking System 2017-2020</p>
         </div>
      </div>
      
    </footer>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>